Marvel Phase Tracker - مشروع Android جاهز للبناء

المشروع يغلّف ملف Marvel Phase Tracker داخل تطبيق Android باستخدام WebView.
القوائم ومربعات المشاهدة تعمل محليًا، والتقدم يُحفظ على نفس تثبيت التطبيق عبر localStorage.

لإنشاء APK:
1) ثبّت Android Studio على الكمبيوتر.
2) افتح Android Studio واختر Open.
3) اختر مجلد MarvelTracker بعد فك ضغط الملف.
4) انتظر Gradle Sync واكتمال تنزيل مكونات Android المطلوبة.
5) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد نجاح البناء اضغط Locate للوصول إلى app-debug.apk.
7) انقل APK إلى هاتف Android وثبّته. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

ملاحظات:
- هذا ملف مشروع Android وليس APK مبنيًا.
- يحتاج Android Studio واتصال إنترنت أول مرة لتنزيل Gradle/SDK.
- بعد تثبيت التطبيق، محتوى القائمة يعمل دون إنترنت.
- التقدم محفوظ داخل بيانات التطبيق؛ حذف التطبيق قد يحذف التقدم.
